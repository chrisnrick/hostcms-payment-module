<?php
beGateway_Settings::setShopId(361);
beGateway_Settings::setShopKey('b8647b68898b084b836474ed8d61ffe117c9a01168d867f24953b776ddcb134d');
?>
