<?php
\beGateway\Settings::$shopId = 361;
\beGateway\Settings::$shopKey = 'b8647b68898b084b836474ed8d61ffe117c9a01168d867f24953b776ddcb134d';
?>
