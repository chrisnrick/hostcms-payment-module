<?php
class beGateway_Payment extends beGateway_Authorization {
}
?>
