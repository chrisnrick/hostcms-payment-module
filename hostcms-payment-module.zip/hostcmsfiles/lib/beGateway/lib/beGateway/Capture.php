<?php
class beGateway_Capture extends beGateway_ChildTransaction {
}
?>
