<?php
class beGateway_Settings {
  public static $shopId;
  public static $shopKey;
  public static $gatewayBase = 'https://demo-gateway.begateway.com';
  public static $checkoutBase = 'https://checkout.begateway.com';
}
?>
